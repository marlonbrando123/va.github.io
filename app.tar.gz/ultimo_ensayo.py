

from ctypes import alignment
from turtle import bgcolor
import flet as ft
import math 



class UI(ft.UserControl):
    def __init__(self,page):
        super().__init__(expand=True)
        self.color_azul = "#2A788E"
        self.color_mora = "#440154"
        self.color_verde_esmeralda = "#35B779"
        self.color_ultra ="#44015450"
        self.color_azul_2= "#0D08850"
        # paleta de colores nueva
        self.color_urban = "#2C3E50"
        self.color_carmesi = "#E74C3C"
        self.color_gris = "#ECF0F1"
        self.color_chiclamino = "#3498DB"
        
        self.navegador=ft.Container(col=1,
                                    border_radius=10,
                                    gradient=ft.LinearGradient(
                                       begin=ft.alignment.top_left,
                                       end=ft.Alignment(0.8,1),
                                       colors=[ "0xff1f005c",
                                                "0xff5b0060",
                                                "0xff870160",
                                                "0xffac255e",
                                                "0xffca485c",
                                                "0xffe16b5c",
                                                "0xfff39060",
                                                "0xffffb56b"
                                               ],
                                               tile_mode=ft.GradientTileMode.MIRROR,
                                               rotation=math.pi/6,

                                   )
                                    ,alignment=ft.alignment.center,
                                    content=ft.NavigationRail(height=593,
                                        bgcolor="0xff5b0060",
                                         selected_index=1,
                                         min_width=500,
                                         min_extended_width=400,
                                         group_alignment=-1,
            destinations=[ft.NavigationRailDestination(label="Inicio",icon=ft.icons.HOME,selected_icon=ft.icons.HOME_MAX_OUTLINED),
                          ft.NavigationRailDestination(label="Buscar",icon=ft.icons.SEARCH,selected_icon=ft.icons.SEARCH_OUTLINED),
                          ft.NavigationRailDestination(label="Ajustes",icon=ft.icons.SETTINGS,selected_icon=ft.icons.SETTINGS_ACCESSIBILITY_OUTLINED),
                          ]
        ))
        
        self.cont_3 =ft.Container(  height=40,
                                    alignment=ft.alignment.center,
                                    content=ft.TextButton(
                                    width=350,
                                    col=10,
                                    content=ft.Row( 
                                        [ft.Image(src="pruebas1\instagram.png",width=31, height=31,fit=ft.ImageFit.CONTAIN,border_radius=20),
                                         ft.Image(src="pruebas1\Face.png",width=31, height=31,fit=ft.ImageFit.CONTAIN,border_radius=10),
                                         ft.Image(src="pruebas1\yu.png",width=31, height=31,fit=[ft.ImageFit.FILL,ft.ImageFit.COVER],border_radius=10,color_blend_mode=10),
                                         ],
                                         alignment=ft.MainAxisAlignment.CENTER
                                    )))
        self.cont_1 = ft.Container(col=11,
                                   gradient=ft.LinearGradient(
                                       begin=ft.alignment.top_left,
                                       end=ft.Alignment(0.8,1),
                                       colors=[ "0xff1f005c",
                                                "0xff5b0060",
                                                "0xff870160",
                                                "0xffac255e",
                                                "0xffca485c",
                                                "0xffe16b5c",
                                                "0xfff39060",
                                                "0xffffb56b"
                                               ],
                                               tile_mode=ft.GradientTileMode.MIRROR,
                                               rotation=math.pi/6,

                                   ),
                                   border_radius=10,
                                   height=610,
                                   alignment=ft.alignment.center,
                                   bgcolor=self.color_mora,
                                   content=ft.Column([ft.Row(controls=[ft.TextButton("Elaboración de horario",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"hola mundo": self.color_mora}   ))],alignment=ft.MainAxisAlignment.CENTER),
                                                      ft.Row(
                                                          [ft.FilledButton("Agregar Horario",icon=ft.icons.ADD, icon_color="GREEN",style=ft.ButtonStyle(bgcolor=self.color_carmesi,color=self.color_gris)),
                                                           ft.FilledButton("Nueva pagina para Horario",icon=ft.icons.PAGES_OUTLINED,icon_color="blue",on_click=self.boton_click,style=ft.ButtonStyle(bgcolor=self.color_carmesi,color=self.color_gris)),
                                                           ft.FilledButton("Eliminar Horario",icon=ft.icons.DELETE_FOREVER, icon_color="yellow",style=ft.ButtonStyle(bgcolor=self.color_carmesi,color=self.color_gris)) ],
                                                           alignment=ft.MainAxisAlignment.SPACE_AROUND),
                                                           ft.Container(
                                                                        content=ft.Row([ft.ElevatedButton(bgcolor=self.color_mora ,content=ft.Container(content=ft.Column([ft.TextButton("HORARIO")])),elevation=30, ),
                                                                                       
                                                                                        ft.ElevatedButton(bgcolor=self.color_mora,content=ft.Container(content=ft.Column([ft.TextButton("LUNES")])),elevation=30),
                                                                                        
                                                                                        ft.ElevatedButton(bgcolor=self.color_mora,content=ft.Container(content=ft.Column([ft.TextButton("MARTES")])),elevation=30,),
                                                                                        
                                                                                        ft.ElevatedButton(bgcolor=self.color_mora,content=ft.Container(content=ft.Column([ft.TextButton("MIERCOLES")])),elevation=30,),
                                                                                        
                                                                                        ft.ElevatedButton(bgcolor=self.color_mora,content=ft.Container(content=ft.Column([ft.TextButton("JUEVES")])),elevation=30, ),
                                                                                        
                                                                                        ft.ElevatedButton(bgcolor=self.color_mora,content=ft.Container(content=ft.Column([ft.TextButton("VIERNES")])),elevation=30 ),
                                                                                        
                                                                                        ], 
                                                                                 alignment=ft.MainAxisAlignment.SPACE_AROUND,spacing=10),
                                                                        alignment=ft.alignment.center,
                                                                        bgcolor=self.color_chiclamino,
                                                                        border_radius=10,
                                                                        ),
                                                                        ft.Container(col=5,
                                                                                     alignment=ft.alignment.center,
                                                                                    content=ft.Row([ft.Column([ft.FilledButton("7:00"),
                                                                                                    ft.FilledButton("8:00"),
                                                                                                    ft.FilledButton("9:00"),
                                                                                                    ft.FilledButton("10:00"),
                                                                                                    ft.FilledButton("11:00"),
                                                                                                    ft.FilledButton("12:00"),
                                                                                                    ft.FilledButton("13:00"),
                                                                                                    ft.FilledButton("14:00")],
                                                                                                    ),
                                                                                                    ft.Column([ft.FilledButton("7:00"),
                                                                                                    ft.Column([ft.FilledButton("Materia")]),
                                                                                                    ft.FilledButton("9:00"),
                                                                                                    ft.FilledButton("10:00"),
                                                                                                    ft.FilledButton("11:00"),
                                                                                                    ft.FilledButton("12:00"),
                                                                                                    ft.FilledButton("13:00"),
                                                                                                    ft.FilledButton("14:00")],
                                                                                                    ),
                                                                                                    ft.Column([ft.FilledButton("7:00"),
                                                                                                    ft.FilledButton("8:00"),
                                                                                                    ft.FilledButton("9:00"),
                                                                                                    ft.FilledButton("10:00"),
                                                                                                    ft.FilledButton("11:00"),
                                                                                                    ft.FilledButton("12:00"),
                                                                                                    ft.FilledButton("13:00"),
                                                                                                    ft.FilledButton("14:00")],
                                                                                                    ),
                                                                                                    ft.Column([ft.FilledButton("7:00"),
                                                                                                    ft.FilledButton("8:00"),
                                                                                                    ft.FilledButton("9:00"),
                                                                                                    ft.FilledButton("10:00"),
                                                                                                    ft.FilledButton("11:00"),
                                                                                                    ft.FilledButton("12:00"),
                                                                                                    ft.FilledButton("13:00"),
                                                                                                    ft.FilledButton("14:00")],
                                                                                                    ),
                                                                                                    ft.Column([ft.FilledButton("7:00"),
                                                                                                    ft.FilledButton("8:00"),
                                                                                                    ft.FilledButton("9:00"),
                                                                                                    ft.FilledButton("10:00"),
                                                                                                    ft.FilledButton("11:00"),
                                                                                                    ft.FilledButton("12:00"),
                                                                                                    ft.FilledButton("13:00"),
                                                                                                    ft.FilledButton("14:00")],
                                                                                                    ),
                                                                                                    ft.Column([ft.FilledButton("7:00"),
                                                                                                    ft.FilledButton("8:00"),
                                                                                                    ft.FilledButton("9:00"),
                                                                                                    ft.FilledButton("10:00"),
                                                                                                    ft.FilledButton("11:00"),
                                                                                                    ft.FilledButton("12:00"),
                                                                                                    ft.FilledButton("13:00"),
                                                                                                    ft.FilledButton("14:00")],
                                                                                                    ),
                                                                                                    ],
                                                                                                     alignment=ft.MainAxisAlignment.SPACE_AROUND),
                                                                                                    ),
                                                                                                    
                                                                                                    
                                                                        ft.Container(col=11,content=ft.Row(controls=[ft.DataTable(bgcolor=self.color_verde_esmeralda,
                                                                        data_row_color=self.color_azul_2 ,
                                                                                    columns=[ft.DataColumn(ft.Text("HORA")),
                                                                                                ft.DataColumn(ft.Text("LUNES")),
                                                                                                ft.DataColumn(ft.Text("MARTES")),
                                                                                                ft.DataColumn(ft.Text("MIERCOLES")),
                                                                                                ft.DataColumn(ft.Text("JUEVES")),
                                                                                                ft.DataColumn(ft.Text("VIERNES"))],
                                                                                        rows=[ft.DataRow(
                                                                                            [ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños"))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños"))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños")),
                                                                                            ft.DataCell(ft.Text("me pagas con engaños"))])])],alignment=ft.MainAxisAlignment.CENTER))
                                                                                                    ]))
        self.pagina2 = ft.Container(col=11,
                                   gradient=ft.LinearGradient(
                                       begin=ft.alignment.top_left,
                                       end=ft.Alignment(0.8,1),
                                       colors=[ "0xff1f005c",
                                                "0xff5b0060",
                                                "0xff870160",
                                                "0xffac255e",
                                                "0xffca485c",
                                                "0xffe16b5c",
                                                "0xfff39060",
                                                "0xffffb56b"
                                               ],
                                               tile_mode=ft.GradientTileMode.MIRROR,
                                               rotation=math.pi/6),
                                   border_radius=10,
                                   height=650,
                                   alignment=ft.alignment.center,
                                   bgcolor=self.color_mora,
                                   content=ft.Column(alignment=ft.CrossAxisAlignment.CENTER ,controls=[ft.Row(controls=[ft.TextButton("Elaboración de horario",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"hola mundo": self.color_mora}   ))],alignment=ft.MainAxisAlignment.CENTER),
                                                      ft.Row(
                                                          [ft.FilledButton("Agregar Materia Nueva",icon=ft.icons.ADD, icon_color="GREEN",style=ft.ButtonStyle(bgcolor=self.color_carmesi,color=self.color_gris)),
                                                           ft.FilledButton("Nueva pagina para Horario",icon=ft.icons.PAGES_OUTLINED,icon_color="blue",on_click=self.boton_click,style=ft.ButtonStyle(bgcolor=self.color_carmesi,color=self.color_gris)),
                                                           ft.FilledButton("Eliminar Horario",icon=ft.icons.DELETE_FOREVER, icon_color="yellow",style=ft.ButtonStyle(bgcolor=self.color_carmesi,color=self.color_gris)) ],
                                                           alignment=ft.MainAxisAlignment.SPACE_AROUND),
                                                           
                                                                        ft.Container(content=ft.Row(controls=[ft.DataTable(border_radius=10,data_row_max_height=45,data_row_min_height=30,column_spacing=15,bgcolor=self.color_mora,
                                                                        data_row_color= self.color_verde_esmeralda,
                                                                                    columns=[ft.DataColumn(ft.Container(alignment=ft.alignment.center_right,content=ft.FilledButton("HORA",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_mora,"": self.color_mora})))),
                                                                                                ft.DataColumn(ft.FilledButton("LUNES",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_mora,"": self.color_mora}))),
                                                                                                ft.DataColumn(ft.FilledButton("MARTES",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_mora,"": self.color_mora}))),
                                                                                                ft.DataColumn(ft.FilledButton("MIERCOLES",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_mora,"": self.color_mora}))),
                                                                                                ft.DataColumn(ft.FilledButton("JUEVES",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_mora,"": self.color_mora}))),
                                                                                                ft.DataColumn(ft.FilledButton("VIERNES",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_mora,"": self.color_mora})))],
                                                                                        rows=[ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("8:00-9:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Quimica Analitca\nCon Cruz Cruz", style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Quimica Analitca\nCon Cruz Cruz",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Quimica Analitca\nCon Cruz Cruz",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Quimica Analitca\nCon Cruz Cruz",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("9:00-10:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Aseguramiento de\nCalidad con Orozco",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.FilledButton("Aseguramiento de\nCalidad con Orozco",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("10:00-11:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Aseguramiento de\nCalidad con Orozco",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(" ")),
                                                                                            ft.DataCell(ft.FilledButton("Aseguramiento de\nCalidad con Orozco",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("11:00-12:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.FilledButton("Bacteriologia Medica\n(Labora) con Claudia",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Aseguramiento de\nCalidad con Orozco",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("12:00-01:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.FilledButton("Bacteriologia Medica\n(Labora) con Claudia",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Inmunologia con\nBernardo",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Inmunologia con\nBernardo",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("01:00-02:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.FilledButton("Bacteriologia Medica\n(Labora) con Claudia",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Inmunologia con\nBernardo",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("02:00-03:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(" ")),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("03:00-04:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("04:00-05:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Bacteriologia Medica\n(Teorica) con Irais",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(" ")),
                                                                                            ft.DataCell(ft.FilledButton("Vision Emprendedora \n con Eder",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Laboratorio de\nInmunologia Con Patricia",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("05:00-06:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.FilledButton("Bacteriologia Medica\n(Teorica) con Irais",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Vision Emprendedora \n con Eder",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Laboratorio de\nInmunologia Con Patricia",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(""))]),
                                                                                            ft.DataRow(
                                                                                            [ft.DataCell(ft.FilledButton("06:00-07:00",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text("")),
                                                                                            ft.DataCell(ft.FilledButton("Bacteriologia Medica\n(Teorica) con Irais",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Vision Emprendedora \n con Eder",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.FilledButton("Laboratorio de\nInmunologia Con Patricia",style=ft.ButtonStyle(color=self.color_gris,bgcolor={ft.ControlState.HOVERED: self.color_carmesi,"": self.color_verde_esmeralda}))),
                                                                                            ft.DataCell(ft.Text(""))])])],alignment=ft.MainAxisAlignment.CENTER))
                                                                                                    ,
                                                                        self.cont_3]),)
        
        
        self.contenedor_grid= ft.Container(col=13,alignment=ft.alignment.top_center,
                                           content=ft.DataTable(bgcolor=self.color_verde_esmeralda,
                                               columns=[ft.DataColumn(ft.Text("hola")),
                                                        ft.DataColumn(ft.Text("hola")),
                                                        ft.DataColumn(ft.Text("hola"))]
                                           ))
        self.cont_2= ft.Container(col=13,
                                  height=100,
                                  width=150,
                                  alignment=ft.alignment.center,
                                  bgcolor=self.color_verde_esmeralda,
                                  content=ft.Column([
                                      ft.TextButton("hola mundillo del internet"),
                                      ft.Row( 
                                        [ft.Icon(name=ft.icons.FAVORITE,color="red"),
                                         ft.Icon(name=ft.icons.AUDIO_FILE,color="GREEN"),
                                         ft.Icon(name=ft.icons.BEACH_ACCESS,color="blue"),
                                         ],
                                         alignment=ft.MainAxisAlignment.CENTER
                                    )

                                  ]))
        
        self.contenedor= ft.ResponsiveRow(
         [self.navegador,
          self.pagina2,
          

          ]
             )

    def build(self):
        return self.contenedor
    def boton_click(self,e):
        return print("hola mundo")
    
    

        
def main(page:ft.Page):
    pie= ft.Text("Hecho por Marco Polo Villanueva López")
    page.title="App de Horario estatico"
    page.update()
    page.add(UI(page),pie)
    

ft.app(main)